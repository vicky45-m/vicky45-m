package com.example.project.service;

import com.example.project.model.Answer;
import com.example.project.repository.AnswerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AnswerServiceImplementation implements AnswerService{
    @Autowired
    private AnswerRepository answerRepositary;

    @Override
    public Answer saveAnswer(Answer answer) {
        return answerRepositary.save(answer);
    }

    @Override
    public List<Answer> getAllAnswer() {
        return answerRepositary.findAll();
    }
}
