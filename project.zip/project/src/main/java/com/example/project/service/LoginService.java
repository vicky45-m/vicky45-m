package com.example.project.service;
import com.example.project.model.Login;

import java.util.List;
public interface LoginService {
    public Login saveLogin(Login login);
    public List<Login> getAllLogin();
}

