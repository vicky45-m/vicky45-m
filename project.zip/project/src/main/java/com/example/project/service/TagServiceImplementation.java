package com.example.project.service;

import com.example.project.model.Tag;
import com.example.project.repository.TagRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TagServiceImplementation implements TagService{
    @Autowired
    private TagRepository tagRepositary;

    @Override
    public Tag saveTag(Tag tag) {

        return tagRepositary.save(tag);
    }

    @Override
    public List<Tag> getAllTag() {
        return tagRepositary.findAll();
    }
}
