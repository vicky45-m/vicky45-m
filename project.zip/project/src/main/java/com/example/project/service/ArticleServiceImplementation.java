package com.example.project.service;

import com.example.project.model.Article;
import com.example.project.repository.ArticleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ArticleServiceImplementation implements ArticleService{
    @Autowired
    private ArticleRepository articleRepositary;

    @Override
    public Article saveArticle(Article article) {
        return articleRepositary.save(article);
    }

    @Override
    public List<Article> getAllArticle() {
        return articleRepositary.findAll();
    }
}
