package com.example.project.controller;

public enum Status {
    SUCCESS,
    USER_ALREADY_EXISTS,
    FAILURE
}

