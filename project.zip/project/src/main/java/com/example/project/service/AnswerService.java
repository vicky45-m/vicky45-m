package com.example.project.service;
import com.example.project.model.Answer;

import java.util.List;
public interface AnswerService {
    public Answer saveAnswer(Answer answer);
    public List<Answer> getAllAnswer();
}
