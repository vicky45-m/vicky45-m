package com.example.project.controller;

import com.example.project.model.Article;
import com.example.project.service.ArticleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/Article")
@CrossOrigin

public class ArticleController {

    @Autowired
    private ArticleService articleService;

    @PostMapping("/add")
    public String add(@RequestBody Article article){
        articleService.saveArticle(article);
        return "New Article is added";
    }

    @GetMapping("/getAll")
    public List<Article> getAllArticle(){
        return articleService.getAllArticle();
    }

}
