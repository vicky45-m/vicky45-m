package com.example.project.service;

import com.example.project.model.Question;

import java.util.List;
public interface QuestionService {
    public Question saveQuestion(Question question);
    public List<Question> getAllQuestion();
}