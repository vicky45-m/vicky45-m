package com.example.project.service;

import com.example.project.model.Login;
import com.example.project.repository.LoginRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LoginServiceImplementation implements LoginService{
    @Autowired
    private LoginRepository loginRepositary;

    @Override
    public Login saveLogin(Login login) {
        return loginRepositary.save(login);
    }

    @Override
    public List<Login> getAllLogin() {
        return loginRepositary.findAll();
    }
}
