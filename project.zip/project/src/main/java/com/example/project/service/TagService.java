package com.example.project.service;
import com.example.project.model.Tag;

import java.util.List;
public interface TagService {
    public Tag saveTag(Tag tag);

    public  List<Tag> getAllTag() ;



}

