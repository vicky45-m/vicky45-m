package com.example.project.controller;

import com.example.project.model.Login;
import com.example.project.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/Signup")
@CrossOrigin

public class LoginController {

    @Autowired
    private LoginService loginService;

    @PostMapping("/add")
    public String add(@RequestBody Login login){
        loginService.saveLogin(login);
        return "New Login is added";
    }

    @GetMapping("/getAll")
    public List<Login> getAllLogin(){
        return loginService.getAllLogin();
    }

}
