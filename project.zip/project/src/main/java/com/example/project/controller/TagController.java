package com.example.project.controller;

import com.example.project.model.Tag;

import com.example.project.service.TagService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/Tag")
@CrossOrigin

public class TagController {

    @Autowired
    private com.example.project.service.TagService tagService;

    @PostMapping("/add")
    public String add(@RequestBody Tag tag){
        tagService.saveTag(tag);
        return "New Tag is added";
    }

    @GetMapping("/getAll")
    public  List<Tag> getAllTag(){
        return tagService.getAllTag();
    }

}
