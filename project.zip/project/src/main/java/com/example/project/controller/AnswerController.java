package com.example.project.controller;

import com.example.project.model.Answer;
import com.example.project.service.AnswerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/Answer")
@CrossOrigin

public class AnswerController {

    @Autowired
    private AnswerService answerService;

    @PostMapping("/add")
    public String add(@RequestBody Answer answer){

        answerService.saveAnswer(answer);
        return "New Answer is added";
    }

    @GetMapping("/getAll")
    public List<Answer> getAllAnswer(){
        return answerService.getAllAnswer();
    }

}
