package com.example.project.controller;


import com.example.project.model.Question;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;



@RestController
@RequestMapping("/Question")
@CrossOrigin

public class QuestionController {
    @Autowired
    private com.example.project.service.QuestionService QuestionService;

    @PostMapping("/add")
    public String add(@RequestBody Question question){
        QuestionService.saveQuestion(question);
        return "New Question  is added";
    }

    @GetMapping("/getAll")
    public List<Question> getAllQuestion(){
        return QuestionService.getAllQuestion();
    }

}
