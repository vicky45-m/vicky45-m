package com.example.project.service;


import com.example.project.model.Question;

import com.example.project.repository.QuestionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class QuestionServiceImplementation implements QuestionService{
    @Autowired
    private QuestionRepository QuestionRepositary;

    @Override
    public Question saveQuestion(Question question) {
        return QuestionRepositary.save(question);
    }

    @Override
    public List<Question> getAllQuestion() {
        return QuestionRepositary.findAll();
    }
}
