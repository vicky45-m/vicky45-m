package com.example.project.service;
import com.example.project.model.Article;

import java.util.List;
public interface ArticleService {
    public Article saveArticle(Article article);
    public List<Article> getAllArticle();
}

